import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import './store.js'
import store from './store.js'
import { deposit } from './features/accounts/accountSlice.js'
import { Provider } from 'react-redux'



store.dispatch(deposit(500));
// store.dispatch(withdraw(200));
// store.dispatch(requestLoan(1000,"Buy a car"));
// store.dispatch(payLoan())

// store.dispatch(createCustomer("Steve Jobs",232323))
// store.dispatch(updateCustomer("Dennis Ritcheas"))
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store= {store}>

    <App />
    </Provider>

  </StrictMode>,
)
